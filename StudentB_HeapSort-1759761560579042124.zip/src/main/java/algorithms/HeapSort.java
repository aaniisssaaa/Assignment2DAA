
package algorithms;

import metrics.PerformanceTracker;

public class HeapSort {

    public static void sort(int[] array, PerformanceTracker tracker) {
        if (array == null) {
            throw new IllegalArgumentException("Input array cannot be null");
        }
        
        tracker.reset();
        tracker.startTimer();

        int n = array.length;
        if (n <= 1) {
            tracker.stopTimer();
            return;
        }

        // Phase 1: Bottom-up Heap Construction (Heapify) - O(N)
        // Start from the last non-leaf node (n/2 - 1) and work backwards.
        for (int i = n / 2 - 1; i >= 0; i--) {
            siftDown(array, n, i, tracker);
        }

        // Phase 2: Sortdown - O(N log N)
        // Repeatedly extract the maximum element (root).
        for (int i = n - 1; i > 0; i--) {
            // Swap the root with the last element of the heap
            swap(array, 0, i, tracker);

            // Restore the heap property on the reduced heap (size i)
            siftDown(array, i, 0, tracker);
        }

        tracker.stopTimer();
    }

    /**
     * Optimization: Iterative implementation of siftDown to ensure O(1) auxiliary space.
     * A recursive implementation would use O(log N) stack space.
     * Restores the max-heap property by sifting the element at 'rootIndex' down.
     */
    private static void siftDown(int[] array, int heapSize, int rootIndex, PerformanceTracker tracker) {
        int current = rootIndex;

        // Loop until the heap property is restored
        while (true) {
            int largest = current;
            int leftChild = 2 * current + 1;
            int rightChild = 2 * current + 2;

            // Check if left child is larger than current largest
            if (leftChild < heapSize) {
                tracker.incrementComparisons();
                tracker.incrementArrayAccesses(2); // Read array[leftChild] and array[largest]
                if (array[leftChild] > array[largest]) {
                    largest = leftChild;
                }
            }

            // Check if right child is larger than current largest
            if (rightChild < heapSize) {
                tracker.incrementComparisons();
                tracker.incrementArrayAccesses(2); // Read array[rightChild] and array[largest]
                if (array[rightChild] > array[largest]) {
                    largest = rightChild;
                }
            }

            // If largest is not the current node, swap and continue down the path
            if (largest != current) {
                swap(array, current, largest, tracker);
                current = largest; // Move down iteratively
            } else {
                // Heap property is restored
                break;
            }
        }
    }

    private static void swap(int[] array, int i, int j, PerformanceTracker tracker) {
        tracker.incrementSwapsOrMoves();
        tracker.incrementArrayAccesses(4); // 2 reads, 2 writes
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}


package algorithms;

import metrics.PerformanceTracker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class HeapSortTest {

    private PerformanceTracker tracker;

    @BeforeEach
    void setUp() {
        tracker = new PerformanceTracker();
    }

    @Test
    void testBasicSort() {
        int[] array = {12, 11, 13, 5, 6, 7, 0, -1};
        int[] expected = {-1, 0, 5, 6, 7, 11, 12, 13};
        HeapSort.sort(array, tracker);
        assertArrayEquals(expected, array);
    }

    @Test
    void testEdgeCases() {
        // Empty
        int[] array1 = {};
        HeapSort.sort(array1, tracker);
        assertArrayEquals(new int[]{}, array1);

        // Single Element
        int[] array2 = {42};
        HeapSort.sort(array2, tracker);
        assertArrayEquals(new int[]{42}, array2);
    }

    @Test
    void testSortedAndReverse() {
        int[] sorted = {1, 2, 3, 4, 5};
        int[] reverse = {5, 4, 3, 2, 1};
        int[] expected = {1, 2, 3, 4, 5};
        
        HeapSort.sort(sorted, tracker);
        assertArrayEquals(expected, sorted);

        HeapSort.sort(reverse, tracker);
        assertArrayEquals(expected, reverse);
    }

    @Test
    void testArrayWithDuplicates() {
        int[] array = {5, 2, 5, 1, 2};
        int[] expected = {1, 2, 2, 5, 5};
        HeapSort.sort(array, tracker);
        assertArrayEquals(expected, array);
    }

    @Test
    void testNullInput() {
        assertThrows(IllegalArgumentException.class, () -> {
            HeapSort.sort(null, tracker);
        });
    }

    @Test
    void testLargeRandomInput() {
        int size = 10000;
        int[] array = new int[size];
        Random random = new Random(42);
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt();
        }
        int[] expected = Arrays.copyOf(array, size);
        Arrays.sort(expected);

        HeapSort.sort(array, tracker);
        assertArrayEquals(expected, array);
    }
}

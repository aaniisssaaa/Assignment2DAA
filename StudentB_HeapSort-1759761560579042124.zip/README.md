
# Assignment 2: Heap Sort Implementation (Student B)

This repository contains an in-place implementation of the Heap Sort algorithm using a bottom-up heap construction (Heapify), as part of Assignment 2.

## Features
- In-place Heap Sort implementation.
- Bottom-up heap construction (O(N) time).
- **Optimization:** Iterative `siftDown` implementation for strict O(1) auxiliary space complexity (avoids O(log N) stack space used by recursive implementations).
- Performance tracking (comparisons, swaps, array accesses, time).
- Comprehensive JUnit 5 test suite.
- Flexible CLI interface for benchmarking.

## Project Structure
```
├── src/main/java/
│   ├── algorithms/HeapSort.java
│   ├── metrics/PerformanceTracker.java
│   └── cli/BenchmarkRunner.java
├── src/test/java/
│   └── algorithms/HeapSortTest.java
├── docs/
│   └── analysis-report-shellsort.md (Peer review of Shell Sort)
├── README.md
└── pom.xml
```

## Building and Running

### Prerequisites
- Java JDK 11+
- Maven

### Compiling
```bash
mvn compile
```

### Running Tests
```bash
mvn test
```

### Running the Benchmark CLI
To run the benchmark CLI (after compiling), use the `BenchmarkRunner`.

Example Usage (assuming running from project root via `java -cp target/classes`):
```bash
# HeapSort, 10000 elements, RANDOM input (default)
java -cp target/classes cli.BenchmarkRunner HeapSort 10000

# HeapSort, 5000 elements, SORTED input
java -cp target/classes cli.BenchmarkRunner HeapSort 5000 SORTED

# HeapSort, 1000 elements, REVERSE input
java -cp target/classes cli.BenchmarkRunner HeapSort 1000 REVERSE
```

## Complexity Overview
- **Worst Case:** Θ(N log N)
- **Average Case:** Θ(N log N)
- **Space Complexity:** O(1) auxiliary.
